import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-police-english',
  templateUrl: './police-english.component.html',
  styleUrls: ['./police-english.component.css']
})
export class PoliceEnglishComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
