import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-divorse-english',
  templateUrl: './divorse-english.component.html',
  styleUrls: ['./divorse-english.component.css']
})
export class DivorseEnglishComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
