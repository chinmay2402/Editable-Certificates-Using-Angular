import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-divorse-italian',
  templateUrl: './divorse-italian.component.html',
  styleUrls: ['./divorse-italian.component.css']
})
export class DivorseItalianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
